# 03 XGBoost Loan Approval

An end-to-end classification project for predicting loan approval status using XGBoost and comparing it with multiple classification models.

## Project Structure

```text
03_XGBoost_LoanApproval/
├── app/
├── data/
│   ├── processed/
│   └── raw/
│       └── loan_approval_dataset.csv
├── models/
├── notebooks/
│   └── 03_XGBoost_LoanApproval.ipynb
├── reports/
├── src/
├── .gitignore
├── README.md
└── requirements.txt
```

## Installation

```bash
pip install -r requirements.txt
```

## Notebook

Run:

```text
notebooks/03_XGBoost_LoanApproval.ipynb
```

The notebook trains XGBoost, compares it with other classifiers, saves the final pipeline, and exports the model-comparison report.
