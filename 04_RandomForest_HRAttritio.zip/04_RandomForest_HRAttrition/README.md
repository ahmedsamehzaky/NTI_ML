# 04 Random Forest HR Attrition

An end-to-end employee attrition classification project using Random Forest and several comparison models.

## Project Structure

```text
04_RandomForest_HRAttrition/
├── app/
│   └── streamlit_app.py
├── data/
│   ├── processed/
│   └── raw/
│       └── WA_Fn-UseC_-HR-Employee-Attrition.csv
├── models/
├── notebooks/
│   └── main_notebook.ipynb
├── reports/
│   └── figures/
├── src/
│   ├── __init__.py
│   └── preprocessing.py
├── .gitignore
├── README.md
└── requirements.txt
```

## Installation

```bash
pip install -r requirements.txt
```

## Training

Run:

```text
notebooks/main_notebook.ipynb
```

The notebook saves the selected pipeline, metadata, reports, cleaned data, and evaluation figures.
