# 02 Decision Tree Churn Modelling

This project builds an end-to-end Decision Tree classifier for customer churn prediction and deploys the trained artifacts through a Streamlit dashboard.

## Project Structure

```text
02_DecisionTree_ChurnModelling/
├── data/
│   └── raw/
│       └── Churn_Modelling.csv
├── models/
├── notebooks/
│   └── 02_DecisionTree_ChurnModelling.ipynb
├── streamlit_app.py
├── requirements.txt
└── README.md
```

## Installation

```bash
pip install -r requirements.txt
```

## Training

Open and run:

```text
notebooks/02_DecisionTree_ChurnModelling.ipynb
```

The notebook saves the trained model, scaler, and feature schema inside the `models` directory.

## Deployment

```bash
streamlit run streamlit_app.py
```
